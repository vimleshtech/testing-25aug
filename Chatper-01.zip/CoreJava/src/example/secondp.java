package example;
import java.util.Scanner;
public class secondp
{
	
  public static void main(String[] args)
  {
		  int m,e,h,c,s,roll_no,sum;
		  double avg;
		  String name;
		  Scanner S=new Scanner(System.in);
		  
		  System.out.println("enter valid student name");
		  name=S.next();
		  
		  System.out.println("enter valid roll_no");
		  roll_no=S.nextInt();
		  
		  System.out.println("enter valid marks of Math");
		  m=S.nextInt();
		  
		  System.out.println("enter valid marks of engnlish");
		  e=S.nextInt();
		  
		  System.out.println("enter valid marks of hindi");
		  h=S.nextInt();
		  
		  System.out.println("enter valid marks of computer");
		  c=S.nextInt();
		  
		  System.out.println("enter valid marks of science");
		  s=S.nextInt();
		  
		  sum=m+e+h+c+s;
		  System.out.println("total marks is"+sum);
		  
		  avg=sum/5;
		  System.out.println("average of marks is  "+avg);
		  
		  
		  
		  
		  
  
  }

}

