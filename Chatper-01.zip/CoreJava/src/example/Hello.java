package example;

public class Hello
{
	int a;
	static int b;
	
	public static void main(String[] arg) 
	{

		//a =11;
		//b =44;
		
		Hello o1 = new Hello();
		Hello o2 = new Hello();
		o1.a =11;
		o1.b =11;
		
		o2.a =110;
		o2.b =110;
		
		System.out.println(o1.a);//11   11
		System.out.println(o1.b);//11   110
		System.out.println(o2.a);//110  110 
		System.out.println(o2.b);//110  110
		
		
		
	}
}
