package example;

public class OutputExample {


	public static void main(String[] arg) {
		
		//declare variable
		int a,b,c;
		
		//assign data 
		a=55;
		b =65;
		
		//expression 
		c = a+b;
		
		//output
		System.out.println("sum of two numbers "+c);
		
		
		//print() vs println() - print and new line
		System.out.print("hi");
		System.out.println("Raman");
		
		
		System.out.println("Hi");
		System.out.print("Raman");
		
		
		System.out.println();
		System.out.print("");
		
		
		
		
	}
}
