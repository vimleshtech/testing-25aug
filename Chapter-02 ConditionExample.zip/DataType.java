package day01;

public class DataType {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		byte b =4;
		
		short s =555;
		int i =444455;
		long l  = 5444555555555555l;
		
		float f =444444.33334555f;
		double d=5433345.334554333;
		
		char c='f';
		String st ="fkhfjf jhfgfhgfjhfg hfghf";
		
		boolean bb= true;
		System.out.println(b);
		System.out.println(s);
		System.out.println(i);
		System.out.println(l);
		System.out.println(c);
		System.out.println(st);
		System.out.println(bb);
		
		

	}

}
