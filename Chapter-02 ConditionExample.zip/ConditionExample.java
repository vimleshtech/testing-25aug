package day01;

import java.util.Scanner;

public class ConditionExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a,b,c;
		Scanner sc= new Scanner(System.in);
		
		System.out.println("enter data ");
		a = sc.nextInt();
		
		System.out.println("enter data ");
		b = sc.nextInt();
		
		
		//condition
		if(a>b) {
			System.out.println("a is greater"); //true 
		}
		else {
			System.out.println("b is greater"); //false
		}
		
		//
		
		System.out.println("enter data ");
		c = sc.nextInt();
		
		//if else if else 
		if(a>b && a>c) {
			System.out.println("a is greater");
		}
		else if(b>a && b>c) {
			System.out.println("b is greater");
		}else {
			System.out.println("c is greater");
		}
	}

}
