package fileexample;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public class ExcelExample {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		FileInputStream fs = new FileInputStream("C:\\Users\\User\\Desktop\\filehandling\\Book1.xls");
		
		HSSFWorkbook book  = new HSSFWorkbook(fs);
		//book.getSheetAt(0);
	  	HSSFSheet sheet =  book.getSheet("data");
	  	
		int sc,rc,cc;
		sc = book.getNumberOfSheets(); //sheet count
		
		rc = sheet.getPhysicalNumberOfRows();//row count
		cc = sheet.getRow(0).getPhysicalNumberOfCells(); //cell count
		
		
		System.out.println(sc);
		System.out.println(rc);
		System.out.println(cc);
		
		for(int i=0; i<rc;i++) {
			
			HSSFRow row = sheet.getRow(i);
			
			HSSFCell cel1 = row.getCell(0);
			HSSFCell cel2 = row.getCell(1);
			
			System.out.println(cel1.getStringCellValue()+"\t"+cel2.getStringCellValue());
			
			
			
			
			
		}
		

	}

}
