package fileexample;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class FileReadExample {

	public static void main(String[] args) throws IOException {
		// TODO Auto-genrerated method stub

		FileReader fr = new FileReader("C:\\Users\\User\\Desktop\\filehandling\\myfile.txt");
		BufferedReader br = new BufferedReader(fr);
		
		String data = br.readLine();//read first line
		
		int c =0;
		int wc=0;
		
		while(data != null) {
			c++;
			String arr[] = data.split(" ");
			wc+= arr.length;
			
			System.out.println(data);
			data = br.readLine();
			
			
			
		}
		
		System.out.println("row count "+c);
		System.out.println("word count "+wc);
		
		br.close();
		fr.close();
		
		
	}

}
