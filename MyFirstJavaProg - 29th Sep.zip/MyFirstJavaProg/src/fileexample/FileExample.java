package fileexample;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class FileExample {

	public static void main(String[] args) throws IOException {

		//false : overwrite the file , default is false
		//true : open the file in append mode
		FileWriter fw = new FileWriter("C:\\Users\\User\\Desktop\\filehandling\\myfile.txt",true);
		BufferedWriter bw = new BufferedWriter(fw);
		
		Scanner sc = new Scanner(System.in);
		
		
		/*
		bw.write("hi, this is first file");
		bw.newLine();
		bw.write("test code");
		bw.newLine();
		bw.write("hi, this is first file");
		bw.newLine();
		bw.write("hi, this is first file");
		bw.newLine();
		*/
		
		for(int i=0; i<5; i++) {
			
			System.out.println("enter data ");
			String txt = sc.nextLine();
			
			bw.write(txt);
			bw.newLine();
		}
		bw.close();
		fw.close();
		System.out.println("file is created");
		

	}

}
