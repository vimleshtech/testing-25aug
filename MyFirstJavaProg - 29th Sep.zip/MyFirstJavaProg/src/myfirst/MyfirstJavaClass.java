package myfirst;

public class MyfirstJavaClass {

public static void main(String[] args) {  //  Compiler start point 
	
		// Show My Name 
	
	System.out.println("MY Name is: Satyam ");

	System.out.println("MY Class is : BCA ");
	
	int a=30;
	int b= 20;
	
	int c;
	
	c = a+b;
	System.out.println("Add value of a and b is =" + c );
	
	if(a> b)
	{
		System.out.println("A Is GT ");
	}
	else {
		System.out.println("B is GT ");

		
	}
	
for(int i=1; i<11; i++) {
	
	System.out.println("MY Name Is sudhanshu ");

}

	}

}
